package com.example.SpringBoot_JPA_H2_CRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJpaH2CrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
