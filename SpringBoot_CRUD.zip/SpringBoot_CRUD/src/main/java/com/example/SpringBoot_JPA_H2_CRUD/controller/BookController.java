package com.example.SpringBoot_JPA_H2_CRUD.controller;

import com.example.SpringBoot_JPA_H2_CRUD.model.Book;
import com.example.SpringBoot_JPA_H2_CRUD.repo.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api")
public class BookController {

    @Autowired
    BookRepository repository;

    @GetMapping("/getAllBooks")
    public ResponseEntity<List<Book>> getAllBook(){
        try{
            List<Book> bookList = new ArrayList<>();
            repository.findAll().forEach(bookList::add);

            if(bookList.isEmpty()){
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(bookList,HttpStatus.OK);
        }catch(Exception e){
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @GetMapping("/getBookById/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Long id){
        try {
           Optional<Book> bookObj = repository.findById(id);
           if(bookObj.isPresent()){
               return new ResponseEntity<>(bookObj.get(),HttpStatus.OK);
           }
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        }catch(Exception ex){
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @PostMapping("/addBook")
    public ResponseEntity<Book> addBook(@RequestBody Book book){
        try{
                 Book bookObj = repository.save(book);
                 return new ResponseEntity<>(bookObj, HttpStatus.OK);

        }catch(Exception e){
                return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/updateBook/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable Long id, @RequestBody Book book){
        try{
            Optional<Book> bookData = repository.findById(id);
            if(bookData.isPresent()){
                Book updateBookData = bookData.get();
                updateBookData.setName(updateBookData.getName());
                updateBookData.setAuthor(updateBookData.getAuthor());

                Book bookObj = repository.save(updateBookData);
                return new ResponseEntity<>(bookObj,HttpStatus.OK);
            }
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        }catch(Exception e){
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/deleteBooksById/{id}")
    public ResponseEntity<Book> deleteBooksById(@PathVariable Long id){

        try{
            repository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/deleteAllBooks")
    public ResponseEntity<Object> deleteAllBooks(){
        try{
            repository.deleteAll();
            return new ResponseEntity<>(HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
