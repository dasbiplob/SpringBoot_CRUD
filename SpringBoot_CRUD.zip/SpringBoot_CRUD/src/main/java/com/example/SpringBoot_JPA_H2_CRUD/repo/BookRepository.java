package com.example.SpringBoot_JPA_H2_CRUD.repo;

import com.example.SpringBoot_JPA_H2_CRUD.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {

}
