package com.example.SpringBoot_JPA_H2_CRUD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJpaH2CrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaH2CrudApplication.class, args);
	}

}
